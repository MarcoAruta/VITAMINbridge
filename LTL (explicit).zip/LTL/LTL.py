import time
from vitamin_model_checker.model_checker_interface.explicit.LTL.pruning import pruning
from vitamin_model_checker.model_checker_interface.explicit.LTL.strategies import initialize, generate_strategies, generate_guarded_action_pairs
from vitamin_model_checker.model_checker_interface.explicit.Solution_Concepts.Solution_Concepts import *
#Non presente in Solution_Concepts perchè questo algoritmo stesso è sureWin
def model_checking_sureWin(model, formula, k, agents):
    flag = 2 #sureWin flag
    start_time = time.time()
    found_solution = False
    agent_actions, actions_list, atomic_propositions, CTLformula, agents, cgs, nash_agents, natural_strategies = initialize(model, formula,k, agents, flag)
    i = 1
    while not found_solution and i <= k:
        cartesian_products = generate_guarded_action_pairs(i, agent_actions, actions_list, atomic_propositions)
        strategies_generator = generate_strategies(cartesian_products, i, agents, found_solution)
        for current_strategy in strategies_generator: #deviation exploration for involved agents
            found_solution = pruning(model, agents, CTLformula, current_strategy)
            if found_solution:
                print("Solution found! It is not a Nash Equilibrium!")
                print("Satisfiable formula")
        i += 1
    else:
        if not found_solution:
            print(f"Formula does not satisfy the given model, the game brings to a Nash Equilibrium for the selected agents")
            print("Unsatisfiable formula")


def model_checking_isNotNash(model, formula, k, natural_strategies):
    start_time = time.time()
    flag = 1 #per dire che sto in isNotNash
    # Inizializza e raccoglie tutti i dati necessari
    agent_actions, actions_list, atomic_propositions, CTLformula, agents, cgs, nash_agents = initialize(model, formula, k, flag)
    found_solution = False

    # Se l'utente ha inserito manualmente le strategie naturali, verifichiamo con isNotNash
    if natural_strategies is not None:
        print("\nUtilizzo delle strategie naturali fornite manualmente dall'utente.")
        if isNotNash(cgs, list(range(1, nash_agents + 1)), CTLformula, natural_strategies, k, agent_actions, atomic_propositions):
            elapsed_time = time.time() - start_time
            print("Deviazione trovata: la strategia naturale NON è un Nash Equilibrium!")
            return False
        else:
            elapsed_time = time.time() - start_time
            print("Nessuna deviazione trovata: la strategia naturale risulta essere un Nash Equilibrium!")
            return True


def model_checking_existNash(model, formula, k, agents):
    flag = 3
    start_time = time.time()
    # Inizializza e raccoglie tutti i dati necessari
    agent_actions, actions_list, atomic_propositions, CTLformula, agents, cgs, nash_agents, natural_strategies = initialize(model, formula, k, agents, flag)
    found_solution = False
    for i in range(1, k + 1):
        cartesian_products = generate_guarded_action_pairs(i, agent_actions, actions_list, atomic_propositions)
        strategies_generator = generate_strategies(cartesian_products, i, agents, found_solution)

        # Per ogni strategia collettiva generata
        for current_strategy in strategies_generator:
            # existsNash viene usata per verificare se esiste almeno una deviazione vincente per qualche agente
            if existsNash(cgs, list(range(1, nash_agents + 1)), CTLformula, current_strategy, i, agent_actions, atomic_propositions):
                elapsed_time = time.time() - start_time
                print("Nash Equilibrium trovato!")
                return True

    elapsed_time = time.time() - start_time
    print("The game doesn't lead to a Nash Equilibrium for the selected agents")
    return False
